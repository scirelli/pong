//READ ME

Make sure you have unziped all the files are in the same folder when you go to run it.

//Bugs
I know of a few bugs:
	1. In the lower left hand corner the paddle sometimes misses the ball.
	2. And for some reason the program dosn't always close out.
	3. The screen size menu, doesn't work cause i didn't code anything for it. And i'm not sure if i will.
	4. Also if you jam on two keys at the same time paddle will freeze.

To report any other bugs or questions/comments email:
Themanimal@aol.com